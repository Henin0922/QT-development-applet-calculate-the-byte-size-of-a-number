#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //ui->lineEdit;
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    //bool ok;

    QString tempStr;

    QString valueStr=ui->lineEdit->text();
     long long value =valueStr.toLongLong();
    //int valueInt=valueStr.toInt(&ok);
    //double area=valueInt*valueInt*3.14159;

//    qDebug()<<sizeof(bool);
//    qDebug()<<sizeof(char);
//    qDebug()<<sizeof(short);
//    qDebug()<<sizeof(int);
//    qDebug()<<sizeof(long);
//    qDebug()<<sizeof(long long);
//    qDebug()<<sizeof(float);
//    qDebug()<<sizeof(double);

      long double dv=2;
      int sizeqint8 =pow(dv,8)-1;
//      int sizeqint16=pow(dv,16)-1;
//      int sizeqint32=pow(dv,32)-1;
//      int sizeqint64=pow(dv,64)-1;



      char a;
      int b;
      short int c ;
      double d;

if (value>0 && value<sizeqint8 )
{
    ui->label_2->setText(tempStr.setNum(sizeof(a))+", type:char");
}


int sizeqint =pow(dv,31);
if (value>sizeqint*-1 && value< sizeqint-1 )
{
    ui->label_2->setText(tempStr.setNum(sizeof(b))+", type:int, long int,float");
}

sizeqint =pow(dv,15);
if (value>sizeqint*-1 && value< sizeqint-1 )
{
    ui->label_2->setText(tempStr.setNum(sizeof(c))+", type:short int");
}

sizeqint =pow(dv,31);
if (value>sizeqint*-1 && value< sizeqint-1)
{
    ui->label_2->setText(tempStr.setNum(sizeof(d))+", type:double,long float");
}

//     ui->label_2->setText(tempStr.setNum(sizeof(d)));
//     ui->label_2->setText(tempStr.setNum(sizeof(e)));
//     ui->label_2->setText(tempStr.setNum(sizeof(f)));
//     ui->label_2->setText(tempStr.setNum(sizeof(g)));
//     ui->label_2->setText(tempStr.setNum(sizeof(h)));
//     ui->label_2->setText(tempStr.setNum(sizeof(i)));

}
